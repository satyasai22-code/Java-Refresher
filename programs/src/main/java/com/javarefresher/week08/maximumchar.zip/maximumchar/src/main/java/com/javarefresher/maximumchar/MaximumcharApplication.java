package com.javarefresher.maximumchar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaximumcharApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaximumcharApplication.class, args);
	}

}
